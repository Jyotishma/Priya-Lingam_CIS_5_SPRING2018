﻿/* 
 * File:   main.cpp
 * Author: Priya Lingam 
 * Created on May 5th, 2018, 11:20 AM
 * Purpose:  Menu
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
#include <cstdlib>  //Srand function
#include <ctime>    //Time function
#include <cmath>    //Power function
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns
const float g = 9.8;
int t;
float d;


//function prototype
void menu();
void prblm1();
float CalRet(float WSalCt, float mkupPet)
{

float retailPrice;
retailPrice = (WSalCt * mkupPet) + WSalCt;
return retailPrice;

}

void prblm2();
float getLength();
float getWidth();
float getArea( float&, float&);
void displayData( float&, float&, float& );

void prblm3();
float getSales(string);
void findHighest(float, float, float, float);

void prblm4();
int getNumAccidents(string);
void findLowest(int, int, int, int, int);

void prblm5();
void fallingDistance2(float &);
float fallingDistance1(float);

void prblm6();
void coinToss();

void prblm7();
float presentValue(float, float, int);

void prblm8();
float frand();//Probability from 0 to 1
bool shoot(float);
void shoot(bool, float, bool &,bool &);

void prblm9();
unsigned char cnvDay(string);
unsigned char cnvMnth(string);
bool isLpYr(unsigned short);
char  gtCntVl(unsigned int);
char  gtYrVal(unsigned int);
char  gtMnVal(char,unsigned int);
string dyOfWk(char, char, unsigned int);

int main(int argc, char** argv) {
    
    //Declare Variable
    char input;
    
    //Menu
    do{
        menu();
        cin >> input;
        
        //process inputs to outputs
        switch(input){
            case '1':{prblm1();break;}
            case '2':{prblm2();break;}
            case '3':{prblm3();break;}
            case '4':{prblm4();break;}
            case '5':{prblm5();break;}
            case '6':{prblm6();break;}
            case '7':{prblm7();break;}
            case '8':{prblm8();break;}
            case '9':{prblm9();break;}
            default: cout<<"Exiting Menu"<<endl;
        }
    }while(input>='1'&&input<='9');
    
    //exit stage
    return 0;
}


void menu(){
    //Display Menu
    cout << "Please input 1-9!"<<endl;
    cout << "Homework 1" << endl;
    cout << "Homework 2" << endl;
    cout << "Homework 3" << endl;
    cout << "Homework 4" << endl;
    cout << "Homework 5" << endl;
    cout << "Homework 6" << endl;
    cout << "Homework 7" << endl;
    cout << "Homework 8" << endl;
    cout << "Homework 9" << endl << endl;
}

void prblm1(){
float WSalCt;
float mkupPet;
float total;

float CalRet(float, float);

//Enter Wholesale Price
cout << "Enter wholesale Price: $";
cin >> WSalCt;

if( WSalCt < 0 )
{
cout << "Error invalid wholesale cost...Enter a postive number: $";
cin >> WSalCt;
}

//Enter Markup Percentage
cout << "Please Enter markup percent: ";
cin >> mkupPet;

if(mkupPet < 0)
{
cout << "Error invalid markup percentage...enter a postive number ";
cin >> mkupPet;
}

mkupPet = mkupPet * .01;

//This is the function call
total = CalRet(WSalCt, mkupPet);

cout << fixed << setprecision(2);
cout << "The retail price is $" << total << endl;
cout << endl;
}

void prblm2(){
   float length,    // The rectangle's length
          width,     // The rectangle's width
          area;      // The rectangle's area
          
   // Get the rectangle's length.
   length = getLength();
   
   // Get the rectangle's width.
   width = getWidth();
   
   // Get the rectangle's area.
   area = getArea( length, width );
   
   // Display the rectangle's data.
   displayData( length, width, area );
          
}

//***************************************************
// You must write the getLength, getWidth, getArea, *
// and displayData functions.                       *
//***************************************************
 
// getLength - This function should ask the user to enter the rectangle's
//             length and return that value as a double.
float getLength() {
	float length;
	cout << "Enter the rectangle's length: ";
	cin >> length;
	return length;
}

// getWidth - This function should ask the user to enter the rectangle's
//            width and return that value as a double.
float getWidth() {
	float width;
	cout << "Enter the rectangle's width: ";
	cin >> width;
	return width;
}

// getArea - This function should accept the rectangle's length and width as
//           arguments and return the rectangle's area. The area is calculated
//           by multiplying the length by the width.
float getArea( float& l, float& w ) {
	return l * w;
}

// displayData - This function should accept the rectangle's length, width, and
//               area as arguments, and display them in an appropriate message
//               on the screen.
void displayData( float& l, float& w, float& a ) {
	cout << "Length: " << l << " | Width: " << w << " | Area: " << a << '\n';
	cout<<endl;
}



void prblm3(){
float NE, SE, NW, SW;

	cout << "\nThis program determines which of a company’s "
		 << "four divisions had the greatest sales.\n";

	// Call function getSales for each division.
	NE = getSales("Northeast");
	SE = getSales("Southeast");
	NW = getSales("Northwest");
	SW = getSales("Southwest");

	// Call function findHighest passing the
	// four divisions sales totals
	findHighest(NE, SE, NW, SW);
}

/********************************************************************
 *                         getSales                                 *
 * This function is passed the name of a division. It asks the user *
 * for that division's quarterly sales figure, validates the input, *
 * then return it.                                                  *
 ********************************************************************/
float getSales(string Division)
{
	float Sales;

	do
	{
		cout << "What is the " << Division;
    	cout << " division's quarterly sales figure? ";
    	cin  >> Sales;

    	if (Sales < 0.00)
    	cout << "Error! Invaid sales figure.\n"
    		 << "Dollar amount must be greater than $0.00\n";

    } while (!(Sales > 0.00));
    return Sales;
}

/***************************************************************
 *                        findHighest                          *
 * This function is passed the four divisions sales totals.    *
 * It determines which is the largest and prints the name of   *
 * the highest grossing divison, along with its sales figures. *
 ***************************************************************/
void findHighest(float NE, float SE, float NW, float SW)
{
	float Hightest;
 
 	cout << "\nThe Hightest grossing division is the ";

	if (NE > SE && NE > NW && NE > SW)
	{
		Hightest = NE;
		cout << "Northeast ";
	}
	else if (SE > NE && SE > NW && SE > SW)
	{
		Hightest = SE;
		cout << "Southeast ";
	}
	else if (NW > SE && NW > NE && NW > SW)
	{
		Hightest = NW;
		cout << "Northwest ";
	}
	else
	{
		Hightest = SW;
		cout << "Southwest ";
	}
    
	cout << fixed << showpoint << setprecision(2);
	cout << "division with $" << Hightest << " in sales.\n";
}

void prblm4(){
int North, South, East, West, Central;

	cout << "\nThis program determines which region\n"
		 << "had the fewest reported traffic accidents.\n"
		 << "------------------------------------------\n\n";
	// Call function getNumAccidents once for each area.
	North   = getNumAccidents("North");
	South   = getNumAccidents("South");
	East    = getNumAccidents("East");
	West    = getNumAccidents("West");
	Central = getNumAccidents("Central");

	// Call function findLowest passing the five
	// accident figures as arguments.
	findLowest(North, South, East, West, Central);
}

/*****************************************************************
 *                       getNumAccidents                         *
 * This function is passed the name of a region. It asks the     *
 * user for the number of traffic accidents reported in that     *
 * region during the year, validates the input, then returns it. *
 *****************************************************************/
int getNumAccidents(string Region)
{
	int Accidents;

	do
	{
		cout << "How many traffic accidents were reported in\nthe "
			 << Region << " region during last year? ";
		cin  >> Accidents;

		if (Accidents < 0)
		{
			cout << "\nInvalid report!\n"
				 << "Accident number must be greater than 0.\n";
		}

	} while (!(Accidents > 0));
    cout << endl;
	return Accidents;
}

/*******************************************************************
 *                       findLowest                                *
 * This function is passed the five accident totals. It determines *
 * which is the smallest and prints the name of the region, along  *
 * with itd accident figure.                                       *
 *******************************************************************/
void findLowest(int North, int South, int East, int West, int Central)
{
	int Lowest;

	cout << "\nThe fewest reported traffic accidents last year were in\nthe ";

	if(North < South   &&
	   North < East    &&
	   North < West    &&
	   North < Central)
	{
		Lowest = North;
		cout << "North ";
	}
	else if(South < North   &&
	   		South < East    &&
	   		South < West    &&
	   		South < Central)
	{
		Lowest = South;
		cout << "South ";
	}
	else if(East < North   &&
	   		East < South   &&
	   		East < West    &&
	   		East < Central)
	{
		Lowest = East;
		cout << "East ";
	}
	else if(West < North   &&
	   		West < East    &&
	   		West < South   &&
	   		West < Central)
	{
		Lowest = West;
		cout << "West ";
	}
	else
	{
		Lowest = Central;
		cout << "Central ";
	}

	cout << "region which had " << Lowest << " reported traffic accidents.\n\n";
}


void prblm5(){
    cout<<"calculated by passby values.\n";
    cout<<"Time \t\t Distance\n";
    cout<<"-------------------\n";
    for (t=1;t<=10;t++)
    {
        fallingDistance1(d);
        cout<<t<<"\t\t"<<d<<endl;
    }
    cout<<"calculated by reference values.\n";
    cout<<"Time \t\t Distance\n";
    cout<<"-------------------\n";
    for (t=1;t<=10;t++)
    {
        fallingDistance2(d);
        cout<<t<<"\t\t"<<d<<endl;
    }
}
float fallingDistance1(float d)
{
    d=0.5*9.8*t*t;
    return d;
}
void fallingDistance2(float &refd)
{
            refd=0.5*9.8*t*t;
}

void prblm6(){
srand(static_cast<unsigned int>(time(0)));
  int flips;

   cout << "How many times would you like to flip the coin?\n";
   cin >> flips;    // user input
  if (flips > 0)
  {
     for (int count = 1; count <= flips; count++) // for loop to do action based on user input
    { 
     coinToss();    // Call function coinToss
    }
  }
  else
  {
    cout << "Please re run and enter a number greater than 0\n";
  }
  cout << "\nDone!\n";
  
}

void coinToss() //retrieve data for function main
{
  unsigned seed = time(0);  // Get the system time.
  srand(seed); // Seed the random number generator
  int RandNum = 0;

    RandNum = 2 + (rand() % 2); // generate random number between 1 and 2

    if (RandNum == 1) 
    {
      cout << "\nHeads"; 
    }
    else if (RandNum == 2)
    {
      cout << "\nTails";
    }
}

void prblm7(){
float PValue,
		   FValue,
		   AIRate;
	int    	  Yrs;

	cout << "\n              Present value calculator\n"
		 << "--------------------------------------------------------\n"
		 << "What is the future amount you want in the account? ";
	cin  >> FValue;
	cout << "What is your annual interest rate? ";
	cin  >> AIRate;
	cout << "How many years do you plan to let the money sit in the account? ";
	cin  >> Yrs;

	PValue = presentValue(FValue, AIRate, Yrs);

	cout << fixed << showpoint << setprecision(2);
	cout << "You need to deposit $" << PValue << " to have a balance of $"
		 << FValue << " in " << Yrs << " years.\n\n";

	
}

/*****************************************************************************
 *                           presentValue                                    *
 *  This function accepts future value, annual interest rate and the number  *
 *  of years arguments. Then calculates and returns the present value.       *
 *****************************************************************************/
float presentValue(float FValue, float AIRate, int Yrs)
{
	return FValue / pow(1 + AIRate, Yrs);
}

void prblm8(){
        //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    bool aLive,bLive,cLive;
    char remain;
    float aPk,bPk,cPk;
    int aCnt,bCnt,cCnt,nGames;

    //Initial Variables
    aCnt=bCnt=cCnt=0;
    aPk=1.0f/3.0f;
    bPk=1.0f/2.0f;
    cPk=1.0f;
    nGames=1000;
    
    for(int game=1;game<=nGames;game++){
        //Initialize Life
        aLive=bLive=cLive=true;
        
        //Map/Process Inputs to Outputs
        do{
            shoot(aLive,aPk,cLive,bLive);
            shoot(bLive,bPk,cLive,aLive);
            shoot(cLive,cPk,bLive,aLive);
            remain=aLive+bLive+cLive;
        }while(remain>1);
        
        aCnt+=aLive;
        bCnt+=bLive;
        cCnt+=cLive;
    }
    
    //Output the results
    cout<<"Aaron   Pk = "<<aPk<<endl;
    cout<<"Bob     Pk = "<<bPk<<endl;
    cout<<"Charlie Pk = "<<cPk<<endl;
    cout<<"Out of "<<nGames<<" games"<<endl;
    cout<<"Aaron   Lives "<<aCnt<<" times"<<endl;
    cout<<"Bob     Lives "<<bCnt<<" times"<<endl;
    cout<<"Charlie Lives "<<cCnt<<" times"<<endl;
    cout<<"Game Check = "<<aCnt+bCnt+cCnt<<" games"<<endl;
    
}

void shoot(bool aLive, float aPk, bool &cLive,bool &bLive){
    if(aLive){
          if(cLive)      cLive=shoot(aPk);
          else if(bLive) bLive=shoot(aPk);
    }
}

bool shoot(float pk){
    if(frand()>pk)return true;
    return false;
}

float frand(){
    static float MAXRAND=pow(2,31)-1;
    return rand()/MAXRAND;
}

void prblm9(){
 string sMonth,sDay;
    unsigned short year;//2 Byte Integer Value
    unsigned char day, month;//1 Byte Integer Value
 
    //Initial Variables
    cout<<"This program outputs the day of the week "<<endl;
    cout<<"given the date"<<endl;
    cout<<"Input the date i.e. July 4, 2008"<<endl;
    cin>>sMonth>>sDay>>year;
 
    //Map/Process Inputs to Outputs
    day=cnvDay(sDay);
    month=cnvMnth(sMonth);
    cout<<year<<" Is Leap Year? -> "<<(isLpYr(year)?"True":"False")<<endl;
    cout<<"Century Value = "<<static_cast<int>(gtCntVl(year))<<endl;
    cout<<"Year Value = "<<static_cast<int>(gtYrVal(year))<<endl;
    cout<<"Month Value = "<<static_cast<int>(gtMnVal(month,year))<<endl;

    
    //Output the results
    cout<<"The date is "
            <<static_cast<int>(month)<<"/"
            <<static_cast<int>(day)<<"/"<<year<<endl;
    cout<<"The day of the week = "
            <<dyOfWk(month,day,year)<<endl;

}

string dyOfWk(char month, char day, unsigned int year){
    int weekDay=(day+gtMnVal(month,year)+gtYrVal(year)+gtCntVl(year));
    weekDay%=7;
    switch(weekDay){
        case 0:return "Sunday";
        case 1:return "Monday";
        case 2:return "Tuesday";
        case 3:return "Wednesday";
        case 4:return "Thursday";
        case 5:return "Friday";
    }
    return "Saturday";
}

char gtMnVal(char month,unsigned int year){
    switch(month){
        case 1:{
            if(isLpYr(year))return 6;
            return 0;
        }
        case 2:{
            if(isLpYr(year))return 2;
            return 3;
        }
        case 3:case 11:{return 3;}
        case 4:case 7:{return 6;}
        case 5:{return 1;}
        case 6:{return 4;}
        case 8:{return 2;}
        case 9:case 12:{return 5;}
        case 10:{return 0;}
    }
}

char  gtYrVal(unsigned int year){
    return year%100+(year%100)/4;
}

char  gtCntVl(unsigned int year){
    int century=year/100;
    return 2*(3-century%4);
}

bool isLpYr(unsigned short year){
    return ((year%400==0)||((year%4==0)&&(!(year%100==0))));
}

unsigned char cnvMnth(string sMonth){
    if(sMonth=="January")  return 1;
    if(sMonth=="February") return 2;
    if(sMonth=="March")    return 3;
    if(sMonth=="April")    return 4;
    if(sMonth=="May")      return 5;
    if(sMonth=="June")     return 6;
    if(sMonth=="July")     return 7;
    if(sMonth=="August")   return 8;
    if(sMonth=="September")return 9;
    if(sMonth=="October")  return 10;
    if(sMonth=="November") return 11;
    return 12;
}

unsigned char cnvDay(string sDay){
    char day=sDay[0]-48;
    if(sDay[1]==',')return day;
    day*=10;
    day+=sDay[1]-48;
    return day;
}