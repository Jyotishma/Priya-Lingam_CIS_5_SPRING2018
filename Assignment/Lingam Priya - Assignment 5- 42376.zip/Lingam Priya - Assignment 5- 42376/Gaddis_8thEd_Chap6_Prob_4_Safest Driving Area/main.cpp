/* 
 * File:   main.cpp
 * Author:Priya Lingam 
 * Created on May 2nd, 2018, 12:10 PM
 * Purpose:  Safest Driving Area
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
#include <cstdlib>  //Srand function
#include <ctime>    //Time function
#include <cmath>    //Power function
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

// Function Prototypes
int getNumAccidents(string);
void findLowest(int, int, int, int, int);

//Execution Begins Here!
int main(int argc, char** argv) {
//Declare Variables
int North, South, East, West, Central;

	cout << "This program determines which region\n"
		 << "had the fewest reported traffic accidents.\n"
		 << "------------------------------------------"<<endl;
		 
	// Call function getNumAccidents once for each area.
	North   = getNumAccidents("North");
	South   = getNumAccidents("South");
	East    = getNumAccidents("East");
	West    = getNumAccidents("West");
	Central = getNumAccidents("Central");

	// Call function findLowest passing the five
	// accident figures as arguments.
	findLowest(North, South, East, West, Central);

	return 0;
}

/*****************************************************************
 *                       getNumAccidents                         *
 * This function is passed the name of a region. It asks the     *
 * user for the number of traffic accidents reported in that     *
 * region during the year, validates the input, then returns it. *
 *****************************************************************/
int getNumAccidents(string Region)
{
	int Accidents;

	do
	{
		cout << "How many traffic accidents were reported"
			 << Region << " region during last year? "<<endl;
		cin  >> Accidents;

		if (Accidents < 0)
		{
			cout << "Invalid report!"
				 << "Accident number must be greater than 0."<<endl;
		}

	} while (!(Accidents > 0));
    cout << endl;
	return Accidents;
}

/*******************************************************************
 *                       findLowest                                *
 * This function is passed the five accident totals. It determines *
 * which is the smallest and prints the name of the region, along  *
 * with itd accident figure.                                       *
 *******************************************************************/
void findLowest(int North, int South, int East, int West, int Central)
{
	int Lowest;

	cout << "The fewest reported traffic accidents last year were reported"<<endl;

	if(North < South   &&
	   North < East    &&
	   North < West    &&
	   North < Central)
	{
		Lowest = North;
		cout << "North ";
	}
	else if(South < North   &&
	   		South < East    &&
	   		South < West    &&
	   		South < Central)
	{
		Lowest = South;
		cout << "South ";
	}
	else if(East < North   &&
	   		East < South   &&
	   		East < West    &&
	   		East < Central)
	{
		Lowest = East;
		cout << "East ";
	}
	else if(West < North   &&
	   		West < East    &&
	   		West < South   &&
	   		West < Central)
	{
		Lowest = West;
		cout << "West ";
	}
	else
	{
		Lowest = Central;
		cout << "Central ";
	}

	cout << "region which had " << Lowest << " reported traffic accidents." <<endl;
}