/* 
 * File:   main.cpp
 * Author:Priya Lingam 
 * Created on May 3rd, 2018, 4:10 PM
 * Purpose:  Coin Toss
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
#include <cstdlib>  //Srand function
#include <ctime>    //Time function
#include <cmath>    //Power function
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes
void coinToss();

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    srand(static_cast<unsigned int>(time(0)));

//Declare Variables
  int flips;

Initialize Variable
   cout << "How many times would you like to flip the coin?\n";
   cin >> flips;    // user input
  if (flips > 0)
  {
     for (int count = 1; count <= flips; count++) // for loop to do action based on user input
    { 
     coinToss();    // Call function coinToss
    }
  }
  else
  {
    cout << "Please re run and enter a number greater than 0\n";
  }
  cout << "\nDone!\n";
  return 0;
}

void coinToss() //retrieve data for function main
{
  unsigned seed = time(0);  // Get the system time.
  srand(seed); // Seed the random number generator
  int RandNum = 0;

    RandNum = 2 + (rand() % 2); // generate random number between 1 and 2

    if (RandNum == 1) 
    {
      cout << "\nHeads"; 
    }
    else if (RandNum == 2)
    {
      cout << "\nTails";
    }
}