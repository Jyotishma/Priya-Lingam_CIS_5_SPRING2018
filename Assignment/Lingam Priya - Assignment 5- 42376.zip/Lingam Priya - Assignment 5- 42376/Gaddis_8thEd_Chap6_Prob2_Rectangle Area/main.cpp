/* 
 * File:   main.cpp
 * Author:Priya Lingam 
 * Created on May 3rd, 2018, 9:10 AM
 * Purpose: Rectangle Area
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
#include <cstdlib>  //Srand function
#include <ctime>    //Time function
#include <cmath>    //Power function
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes 
float getLgt(); //getLength
float getWid(); //getWidth
float getAre( float&, float&);   //getArea
void dispDa( float&, float&, float& );  //displayData

//Execution Begins Here!
int main(int argc, char** argv) {
//Declare Variables
   float length,    // The rectangle's length
          width,     // The rectangle's width
          area;      // The rectangle's area
          
   // Get the rectangle's length.
   length = getLgt();
   
   // Get the rectangle's width.
   width = getWid();
   
   // Get the rectangle's area.
   area = getAre( length, width );
   
   // Display the rectangle's data.
   dispDa( length, width, area );
          
   return 0;
}

//***************************************************
// You must write the getLength, getWidth, getArea, *
// and displayData functions.                       *
//***************************************************
 
// getLength - This function should ask the user to enter the rectangle's
//             length and return that value as a double.
float getLgt() {
	float length;
	cout << "Enter the rectangle's length: " <<endl;
	cin >> length;
	return length;
}

// getWidth - This function should ask the user to enter the rectangle's
//            width and return that value as a double.
float getWid() {
	float width;
	cout << "Enter the rectangle's width: " <<endl;
	cin >> width;
	return width;
}

// getArea - This function should accept the rectangle's length and width as
//           arguments and return the rectangle's area. The area is calculated
//           by multiplying the length by the width.
float getAre( float& l, float& w ) {
	return l * w;
}

// displayData - This function should accept the rectangle's length, width, and
//               area as arguments, and display them in an appropriate message
//               on the screen.
void dispDa( float& l, float& w, float& a ) {
	cout << "Length: " << l << " | Width: " << w << " | Area: " << a << '\n' <<endl;
}