/* 
 * File:   main.cpp
 * Author:Priya Lingam 
 * Created on May 2nd, 2018, 11:00 AM
 * Purpose:  Markup
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
#include <cstdlib>  //Srand function
#include <ctime>    //Time function
#include <cmath>    //Power function
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

//Function Prototypes
float CalRet(float WSalCt, float mkupPet)   //Wholesalecost, markupPercent, CalculateRetail
{

float retPri;  //retailPrice
retPri = (WSalCt * mkupPet) + WSalCt;
return retPri;

}
//Execution Begins Here!
int main(int argc, char** argv){
//Declare Variables
float WSalCt;
float mkupPet;
float total;

Initialize Variable
float CalRet (float, float);

//Enter Wholesale Price
cout << "Enter wholesale Price: $"<<endl;
cin >> WSalCt;

if( WSalCt < 0 )
{
cout << "Error invalid wholesale cost...Enter a postive number: $"<<endl;
cin >> WSalCt;
}

//Enter Markup Percentage
cout << "Please Enter markup percent: "<<endl;
cin >> mkupPet;

if(mkupPet)
{
cout << "Error invalid markup percentage...enter a postive number "<<endl;
cin >> mkupPet;
}

mkupPet = mkupPet * .01;

//This is the function call
total = CalRet(WSalCt, mkupPet);

cout << fixed << setprecision(2);
cout << "The retail price is $" << total << endl;
cout << endl;

return 0;
}