﻿/* 
 * File:   main.cpp
 * Author:Priya Lingam 
 * Created on May 4th, 2018, 1:10 PM
 * Purpose:  Present Value
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
#include <cstdlib>  //Srand function
#include <ctime>    //Time function
#include <cmath>    //Power function
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns

// Function prototypes
float presentValue(float, float, int);

//Execution Begins Here!
int main(int argc, char** argv) {
//Declare Variables
	float PValue,
		   FValue,
		   AIRate;
	int    	  Yrs;

	cout << "\n              Present value calculator\n"
		 << "--------------------------------------------------------\n"
		 << "What is the future amount you want in the account? ";
	cin  >> FValue;
	cout << "What is your annual interest rate? ";
	cin  >> AIRate;
	cout << "How many years do you plan to let the money sit in the account? ";
	cin  >> Yrs;

	PValue = presentValue(FValue, AIRate, Yrs);

	cout << fixed << showpoint << setprecision(2);
	cout << "You need to deposit $" << PValue << " to have a balance of $"
		 << FValue << " in " << Yrs << " years.\n\n";

	return 0;
}

/*****************************************************************************
 *                           presentValue                                    *
 *  This function accepts future value, annual interest rate and the number  *
 *  of years arguments. Then calculates and returns the present value.       *
 *****************************************************************************/
float presentValue(float FValue, float AIRate, int Yrs)
{
	return FValue / pow(1 + AIRate, Yrs);
}

//• P is the present value, or the amount that you need to deposit today.
	//• F is the future value that you want in the account (in this case, $10,000).
	//• r is the annual interest rate (expressed in decimal form, such as .042).
	//• n is the number of years that you plan to let the money sit in the account.
