/* 
 * File:   main.cpp
 * Author:Priya Lingam 
 * Created on May 3rd, 2018, 9:10 AM
 * Purpose:  Falling Distance
 */

//System Libraries
#include <iostream> //I/O Library -> cout,endl
#include <iomanip>  //Format Library
#include <cstdlib>  //Srand function
#include <ctime>    //Time function
#include <cmath>    //Power function
# include <string>
using namespace std;//namespace I/O stream library created

//User Libraries

//Global Constants
//Math, Physics, Science, Conversions, 2-D Array Columns
const float g = 9.8;

//Function Prototypes
void fallingDistance2(float &);
float fallingDistance1(float);
int t;
float d;

//Execution Begins Here!
int main(int argc, char** argv) {
//Declare Variables

    cout<<"calculated by passby values.\n";
    cout<<"Time \t\t Distance\n";
    cout<<"-------------------\n";
    for (t=1;t<=10;t++)
    {
        
;
        cout<<t<<"\t\t"<<d<<endl;
    }
    cout<<"calculated by reference values.\n";
    cout<<"Time \t\t Distance\n";
    cout<<"-------------------\n";
    for (t=1;t<=10;t++)
    {
        fallingDistance2(d);
        cout<<t<<"\t\t"<<d<<endl;
    }
    return 0;
}
float fallingDistance1(float d)
{
    d=0.5*9.8*t*t;
    return d;
}
void fallingDistance2(float &refd)
{
            refd=0.5*9.8*t*t;
}